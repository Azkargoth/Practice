ifort -o rstokes stokes.f90
