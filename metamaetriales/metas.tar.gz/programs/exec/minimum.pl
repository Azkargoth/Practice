#!/bin/bash
casos=(40x50/s1.5/14/0.510/rt/rt-nt-1.4-140-nm-cross_A0.00_S1.000_f0.510_crystal_Nh_100_epsa_ag_epsb_1.501-0.000_t145 40x50/s1.5/14/0.510/rt/rt-nt-1.4-130-nm-cross_A0.00_S1.000_f0.510_crystal_Nh_100_epsa_ag_epsb_1.501-0.000_t145 40x50/s1.5/14/0.510/rt/rt-nt-1.4-120-nm-cross_A0.00_S1.000_f0.510_crystal_Nh_100_epsa_ag_epsb_1.501-0.000_t145 40x50/s1.5/14/0.510/rt/rt-nt-1.4-110-nm-cross_A0.00_S1.000_f0.510_crystal_Nh_100_epsa_ag_epsb_1.501-0.000_t145 40x50/s1.5/14/0.510/rt/rt-nt-1.4-100-nm-cross_A0.00_S1.000_f0.510_crystal_Nh_100_epsa_ag_epsb_1.501-0.000_t145 40x50/s1.5/14/0.510/rt/rt-nt-1.4-90-nm-cross_A0.00_S1.000_f0.510_crystal_Nh_100_epsa_ag_epsb_1.501-0.000_t145 40x50/s1.5/14/0.510/rt/rt-nt-1.4-80-nm-cross_A0.00_S1.000_f0.510_crystal_Nh_100_epsa_ag_epsb_1.501-0.000_t145 40x50/s1.5/14/0.510/rt/rt-nt-1.4-70-nm-cross_A0.00_S1.000_f0.510_crystal_Nh_100_epsa_ag_epsb_1.501-0.000_t150)
casos=(puta mierda)
  for i in ${casos[@]}
  printf "\t$i\n"
#  mv $i fort.1
#  n=`wc fort.1 | awk '{print $1}'`
#  echo $n | /Users/bms/research/metamaterials/haydock/fields/programs/exec/rminimum
  done
