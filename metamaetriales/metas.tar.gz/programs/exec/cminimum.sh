ifort -o rminimum minimum.f90
